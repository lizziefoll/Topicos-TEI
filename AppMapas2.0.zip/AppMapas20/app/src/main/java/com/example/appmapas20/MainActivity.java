
package com.example.appmapas;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;

import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;


import com.example.appmapas20.R;
import com.github.chrisbanes.photoview.PhotoView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;


public class MainActivity extends AppCompatActivity {

    public TextInputEditText idestadinho;
    public TextView nome;
    public TextView idpopulacao;
    public TextView idarea;
    public TextView ididh;
    public TextView idmunicipios;
    public TextView Resultado;
    public PhotoView IDmapa;

    private RadioButton radioButtonGO;
    private RadioButton radioButtonMT;
    private RadioButton radioButtonMS;
    private RadioButton radioButtonDF;
    private RadioGroup estados;

    private CheckBox checkBoxEstado;
    private CheckBox checkBoxPopulacao;
    private CheckBox checkBoxArea;
    private CheckBox checkBoxIDH;
    private CheckBox checkBoxMun;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        idpopulacao = findViewById(R.id.checkboxPopulacao);
        idarea = findViewById(R.id.checkboxÁrea);
        ididh = findViewById(R.id.checkboxIDH);
        idmunicipios = findViewById(R.id.checkboxmunicipios);
        IDmapa = findViewById(R.id.IDmapa);

        radioButtonGO = findViewById(R.id.radioButtonGO);
        radioButtonMT = findViewById(R.id.radioButtonMT);
        radioButtonMS = findViewById(R.id.radioButtonMS);
        radioButtonDF = findViewById(R.id.radioButtonDF);
        estados = findViewById(R.id.estados);

        checkBoxPopulacao = findViewById(R.id.checkboxPopulacao);
        checkBoxArea = findViewById(R.id.checkboxÁrea);
        checkBoxIDH = findViewById(R.id.checkboxIDH);
        checkBoxMun = findViewById(R.id.checkboxmunicipios);

        radioButtonListener();

    }
    public void radioButtonListener(){
        estados.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                if (checkedId == R.id.radioButtonDF) {
                    IDmapa.setImageResource(R.drawable.mapadf);
                    checkBoxDF();

                } else if (checkedId == R.id.radioButtonGO){
                    IDmapa.setImageResource(R.drawable.mapaGO);
                    checkBoxGO();

                } else if (checkedId == R.id.radioButtonMT){
                    IDmapa.setImageResource(R.drawable.mapaMT);
                    checkboxMT();
                }
                else if (checkedId == R.id.radioButtonMS){
                    IDmapa.setImageResource(R.drawable.mapaMS);
                    checkboxMS();
            }

        );}
    }
        public void checkboxGO() {
            String rr = "";
            if (checkBoxEstado.isChecked()) {
                rr += "Goias\n";
            }
            if (checkBoxArea.isChecked()){
                rr += "Area: 357.125 km².\n";
            } if (checkBoxPopulacao.isChecked()){
                rr += "População: 6,523 milhões.\n";
            } if (checkBoxIDH.isChecked()){
                rr += "IDH:  0,735.\n";
            } if (checkBoxMun.isChecked()){
                rr += "municipios: 79 \n";
            }
            Resultado.setText(rr);


        }

        idpopulacao.setText("População: 6,523 milhões.");
        idarea.setText("Area: 340.086 km².");
        ididh.setText("IDH: 0,735.");
        idmunicipios.setText("Municipios: 246.");

        idpopulacao.setVisibility(View.VISIBLE);
        idarea.setVisibility(View.VISIBLE);
        ididh.setVisibility(View.VISIBLE);
        idmunicipios.setVisibility(View.VISIBLE);

    }

    public void checkboxMS() {
        String rr = "";
        if (checkBoxEstado.isChecked()) {
            rr += "Estado: Mato Grosso do Sul \n";
        }
        if (checkBoxArea.isChecked()){
            rr += "Area: 357.125 km².\n";
        } if (checkBoxPopulacao.isChecked()){
            rr += "População: 11.597.484 hab \n";
        } if (checkBoxIDH.isChecked()){
            rr += "IDH: 0,729.\n";
        } if (checkBoxMun.isChecked()){
            rr += "municipios: 79 \n";
        }
        Resultado.setText(rr);


    }
}
        else if (estado.equals("mato grosso")){

                nome.setText("Mato Grosso");
                nome.setVisibility(View.VISIBLE);

                IDmapa.setImageResource(R.drawable.mapams);
                IDmapa.setVisibility(View.VISIBLE);


                idpopulacao.setText("População: 3,224 milhões.");
                idarea.setText("Area: 903.357 km².");
                ididh.setText("IDH: 0.773.");
                idmunicipios.setText("Municipios: 141.");

                idpopulacao.setVisibility(View.VISIBLE);
                idarea.setVisibility(View.VISIBLE);
                ididh.setVisibility(View.VISIBLE);
                idmunicipios.setVisibility(View.VISIBLE);

                }
                else{
                nome.setText("erro");
                nome.setVisibility(View.VISIBLE);
                }
                }
                }